"use client"

import { signIn, getProviders } from "next-auth/react"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useSearchParams } from "next/navigation"

export default function SignIn() {
  const [providers, setProviders] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)
  const searchParams = useSearchParams()
  const error = searchParams.get("error")

  useEffect(() => {
    const fetchProviders = async () => {
      const res = await getProviders()
      setProviders(res)
    }
    fetchProviders()
  }, [])

  const handleGoogleSignIn = async () => {
    setIsLoading(true)
    try {
      await signIn("google", { callbackUrl: "/learn" })
    } catch (error) {
      console.error("Sign in error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const getErrorMessage = (error: string | null) => {
    switch (error) {
      case "OAuthSignin":
        return "Google認証の設定に問題があります。管理者にお問い合わせください。"
      case "OAuthCallback":
        return "認証が完了しませんでした。もう一度お試しください。"
      case "OAuthCreateAccount":
        return "アカウントの作成に失敗しました。"
      case "EmailCreateAccount":
        return "メールアドレスでのアカウント作成に失敗しました。"
      case "Callback":
        return "認証コールバックでエラーが発生しました。"
      case "OAuthAccountNotLinked":
        return "このメールアドレスは既に他の方法で登録されています。"
      case "EmailSignin":
        return "メールを送信できませんでした。"
      case "CredentialsSignin":
        return "ログイン情報が正しくありません。"
      case "SessionRequired":
        return "このページにアクセスするにはログインが必要です。"
      default:
        return "認証エラーが発生しました。もう一度お試しください。"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-400 to-green-600 flex items-center justify-center p-6">
      <Card className="w-full max-w-md p-8 bg-white rounded-3xl shadow-2xl">
        <div className="text-center">
          {/* Logo/Icon */}
          <div className="mb-8">
            <div className="w-20 h-20 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-4">
              <span className="text-4xl">🦉</span>
            </div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">OwlLearn</h1>
            <p className="text-gray-600">楽しく英語学習を始めましょう！</p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl">
              <p className="text-red-700 text-sm">{getErrorMessage(error)}</p>
            </div>
          )}

          {/* Sign In Button */}
          <div className="space-y-4">
            <Button
              onClick={handleGoogleSignIn}
              disabled={isLoading || !providers?.google}
              className="w-full bg-white hover:bg-gray-50 text-gray-700 border border-gray-300 font-medium py-4 rounded-xl shadow-sm flex items-center justify-center space-x-3"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-gray-300 border-t-gray-600 rounded-full animate-spin" />
              ) : (
                <>
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                  <span>Googleでログイン</span>
                </>
              )}
            </Button>

            <p className="text-xs text-gray-500 text-center leading-relaxed">
              ログインすることで、{" "}
              <span className="text-green-600 font-medium">利用規約</span>と{" "}
              <span className="text-green-600 font-medium">プライバシーポリシー</span>
              に同意したものとみなされます。
            </p>
          </div>

          {/* Features */}
          <div className="mt-8 space-y-3">
            <h3 className="text-lg font-semibold text-gray-800">OwlLearnの特徴</h3>
            <div className="grid grid-cols-1 gap-3 text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <span className="text-green-500">✨</span>
                <span>ゲーム感覚で楽しく学習</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-blue-500">🎯</span>
                <span>段階的なスキルツリー</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-purple-500">🏆</span>
                <span>進捗とストリーク管理</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-red-500">🎤</span>
                <span>スピーキング練習機能</span>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
} 