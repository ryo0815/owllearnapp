"use client"

import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"

export default function AuthError() {
  const searchParams = useSearchParams()
  const error = searchParams.get("error")

  const getErrorMessage = (error: string | null) => {
    switch (error) {
      case "Configuration":
        return "認証の設定に問題があります。管理者にお問い合わせください。"
      case "OAuthSignin":
        return "Google認証の設定に問題があります。"
      case "OAuthCallback":
        return "認証が完了しませんでした。"
      case "OAuthCreateAccount":
        return "アカウントの作成に失敗しました。"
      case "EmailCreateAccount":
        return "メールアドレスでのアカウント作成に失敗しました。"
      case "Callback":
        return "認証コールバックでエラーが発生しました。"
      case "OAuthAccountNotLinked":
        return "このメールアドレスは既に他の方法で登録されています。"
      case "EmailSignin":
        return "メールを送信できませんでした。"
      case "CredentialsSignin":
        return "ログイン情報が正しくありません。"
      case "SessionRequired":
        return "このページにアクセスするにはログインが必要です。"
      default:
        return "認証エラーが発生しました。"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-400 to-red-600 flex items-center justify-center p-6">
      <Card className="w-full max-w-md p-8 bg-white rounded-3xl shadow-2xl">
        <div className="text-center">
          <div className="w-20 h-20 mx-auto bg-red-100 rounded-full flex items-center justify-center mb-4">
            <span className="text-4xl">⚠️</span>
          </div>
          
          <h1 className="text-2xl font-bold text-gray-800 mb-2">認証エラー</h1>
          
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl">
            <p className="text-red-700 text-sm">{getErrorMessage(error)}</p>
            {error && (
              <p className="text-red-500 text-xs mt-2">エラーコード: {error}</p>
            )}
          </div>

          <div className="space-y-3">
            <Link href="/auth/signin">
              <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white">
                サインインページに戻る
              </Button>
            </Link>
            
            <Link href="/">
              <Button variant="outline" className="w-full">
                ホームページに戻る
              </Button>
            </Link>
          </div>
        </div>
      </Card>
    </div>
  )
} 